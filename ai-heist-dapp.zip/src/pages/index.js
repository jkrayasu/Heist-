import HeistGameUI from '../components/HeistGameUI';
export default function Home() { return <HeistGameUI />; }
