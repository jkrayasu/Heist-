# Prompt-Powered Heist 🧠

A web3 game powered by AI, puzzles, and cryptoeconomic mechanics.

## 🚀 One-Click Deploy
[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/import?s=https://github.com/YOUR_USERNAME/ai-heist-dapp&env=NEXT_PUBLIC_GAME_CONTRACT,NEXT_PUBLIC_CHAIN_ID&envDescription=Enter%20your%20smart%20contract%20address%20and%20chain%20ID)

## 👤 Created By
This project was founded and designed by YOU.
